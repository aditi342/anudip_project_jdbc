package Exceptions;

public class CustomerException extends Exception {
	public CustomerException(){
		
	}
	
	public CustomerException(String str){
		super(str);
	}
}
