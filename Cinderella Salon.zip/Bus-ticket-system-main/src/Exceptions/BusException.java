package Exceptions;

public class BusException extends Exception{
	public BusException() {
		
	}
	
	public BusException(String message) {
		super (message);
	}
}
