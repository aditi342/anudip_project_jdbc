# Bus-ticket-system
Bus Ticket Reservation System Using Java
here the admin can login,add new bus, update satus,view all tickets.
Customer can signup,login,book tocket,view ticket.

This is console based project using JDBC we are connecting with database 
